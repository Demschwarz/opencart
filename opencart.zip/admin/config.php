<?php
// HTTP
define('HTTP_SERVER', 'http://demschwarz.ru/admin/');
define('HTTP_CATALOG', 'http://demschwarz.ru/');

// HTTPS
define('HTTPS_SERVER', 'http://demschwarz.ru/admin/');
define('HTTPS_CATALOG', 'http://demschwarz.ru/');

// DIR
define('DIR_APPLICATION', '/var/www/demsc195/data/www/demschwarz.ru/admin/');
define('DIR_SYSTEM', '/var/www/demsc195/data/www/demschwarz.ru/system/');
define('DIR_IMAGE', '/var/www/demsc195/data/www/demschwarz.ru/image/');
define('DIR_LANGUAGE', '/var/www/demsc195/data/www/demschwarz.ru/admin/language/');
define('DIR_TEMPLATE', '/var/www/demsc195/data/www/demschwarz.ru/admin/view/template/');
define('DIR_CONFIG', '/var/www/demsc195/data/www/demschwarz.ru/system/config/');
define('DIR_CACHE', '/var/www/demsc195/data/www/demschwarz.ru/system/storage/cache/');
define('DIR_DOWNLOAD', '/var/www/demsc195/data/www/demschwarz.ru/system/storage/download/');
define('DIR_LOGS', '/var/www/demsc195/data/www/demschwarz.ru/system/storage/logs/');
define('DIR_MODIFICATION', '/var/www/demsc195/data/www/demschwarz.ru/system/storage/modification/');
define('DIR_UPLOAD', '/var/www/demsc195/data/www/demschwarz.ru/system/storage/upload/');
define('DIR_CATALOG', '/var/www/demsc195/data/www/demschwarz.ru/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'demsc195_test');
define('DB_PASSWORD', '61asovaf');
define('DB_DATABASE', 'demsc195_test');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
